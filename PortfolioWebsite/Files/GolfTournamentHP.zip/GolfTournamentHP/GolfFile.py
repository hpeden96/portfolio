# Hunter Peden
# 10-26-20
# This program creates a data file from the user input, validates numeric, string, and range of variables
# Handles IOError exceptions

def main():
    cFile = init()
    for x in range(1, 11):
        iName = inputName()
        iYear = inputYear()
        iMonth = inputMonth()
        iDay = inputDay(iMonth)
        iAge = inputAge()
        iHandicap = inputHandicap()
        iScore = inputScore()
        output(iName, iYear, iMonth, iDay, iAge, iHandicap, iScore, cFile)
    closing(cFile)


def init():
    cFile = open(r'/Users/hunter/Documents/Python/golf.dat', 'w')
    return cFile


def inputName():
    valid = False
    while not valid:
        iName = (input("Please enter your name: "))
        if iName == "":
            print("Error. Name is required. Can't be blank.")
        else:
            valid = True
    return iName


def inputYear():
    valid = False
    while not valid:
        try:
            iYear = int(input("Please enter year of the tournament: "))
        except:
            print("Error. Year must be a whole number.")
        else:
            if iYear <= 2019:
                print("Error. Must be tournament from 2020.")
            else:
                valid = True

    return iYear


def inputMonth():
    valid = False
    while not valid:
        try:
            iMonth = int(
                input("Please enter month of the tournament (1-12): "))
        except:
            print("Error. Month must be a whole number. ")
        else:
            if iMonth < 1 or iMonth > 12:
                print("Error. Must be a month 1-12.")
            else:
                valid = True

    return iMonth


def inputDay(iMonth):
    valid = False
    while not valid:
        try:
            if iMonth == 1 or iMonth == 3 or iMonth == 5 or iMonth == 7 or iMonth == 8 or iMonth == 10 or iMonth == 12:
                iDay = int(input("Please enter day of the tournament: "))
                if iDay > 31 or iDay < 0:
                    print("Error. Day must be between 1-31.")
                else:
                    valid = True
            elif iMonth == 2:
                iDay = int(input("Please enter day of the tournament: "))
                if iDay > 28 or iDay < 0:
                    print("Error. Day must be between 1-28.")
                else:
                    valid = True
            else:
                iDay = int(input("Please enter day of the tournament: "))
                if iDay > 30 or iDay < 0:
                    print("Error. Day must be between 1-30.")
                else:
                    valid = True

        except:
            print("Error. Day must be a whole number.")

    return iDay


def inputAge():
    valid = False
    while not valid:
        try:
            iAge = int(input("Please enter your age: "))
        except:
            print("Error. Age must be a whole number.")
        else:
            if iAge < 10 or iAge > 99:
                print("Error. Must be between 10-99. Retry")
            else:
                valid = True

    return iAge


def inputHandicap():
    valid = False
    while not valid:
        try:
            iHandicap = int(input("Please enter handicap: "))
        except:
            print("Error. Handicap must be a whole number.")
        else:
            if iHandicap > 30:
                print("Error. Handicap must be between 0-30.")
            else:
                valid = True

    return iHandicap


def inputScore():
    valid = False
    while not valid:
        try:
            iScore = int(input("Please enter score: "))
        except:
            print("Error. Score must be a whole number.")
        else:
            if iScore < 18 or iScore > 150:
                print("Error. Score must be between 18-150.")
            else:
                valid = True

    return iScore


def output(iName, iYear, iMonth, iDay, iAge, iHandicap, iScore, cFile):
    cFile.write(format(iName, "25s") + format(iYear) + ("%02d" % iMonth) +
                ("%02d" % iDay) + format(iAge) + ("%02d" % iHandicap) + ("%03d" % iScore) + "\n")


def closing(cFile):
    cFile.close()


main()
