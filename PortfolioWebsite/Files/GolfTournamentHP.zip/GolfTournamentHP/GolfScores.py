# Hunter Peden
# Lab 5
# Entering records into program and determining the 1st and 2nd place winner

import datetime

# Global Variable Definition
oDate = " "
cPctr = 0
cLctr = 0
cJuniorTotal = 0
cJuniorCount = 0
cJuniorFirst = 0
cJuniorSecond = 0
oJuniorFirst = " "
oJuniorSecond = " "
cAmateurTotal = 0
cAmateurCount = 0
cAmateurFirst = 0
cAmateurSecond = 0
oAmateurFirst = " "
oAmateurSecond = " "
cSeniorTotal = 0
cSeniorCount = 0
cSeniorFirst = 0
cSeniorSecond = 0
oSeniorFirst = " "
oSeniorSecond = " "
juniorTemp = 500
amateurTemp = 500
seniorTemp = 500


def main():
    iRec, playerFile = init()
    while(iRec != ""):
        iFinalScore = calcs(iRec)
        output(iRec, iFinalScore)
        iRec = read(playerFile)

    closing(playerFile)


def output(iRec, iFinalScore):
    iName = iRec[0:25]
    iDate = iRec[25:33]
    iAge = iRec[33:35]
    iHandicap = iRec[35:37]
    iScore = iRec[37:40]

    oRecDate = datetime.datetime.strptime(
        str(iDate), '%Y%m%d').strftime('%m/%d/%Y')
    print(iName, format(" ", "2s"), oRecDate, format(" ", "4s"), iAge,
          format(" ", "9s"), iHandicap, format(" ", "14s"), iScore, format(
              " ", "7s"), ("%03d" % iFinalScore))


def calcs(iRec):
    global cJuniorTotal
    global cJuniorCount
    global cJuniorFirst
    global cJuniorSecond
    global oJuniorFirst
    global oJuniorSecond
    global cAmateurTotal
    global cAmateurCount
    global cAmateurFirst
    global cAmateurSecond
    global oAmateurFirst
    global oAmateurSecond
    global cSeniorTotal
    global cSeniorCount
    global cSeniorFirst
    global cSeniorSecond
    global oSeniorFirst
    global oSeniorSecond
    global juniorTemp
    global amateurTemp
    global seniorTemp

    iName = iRec[0:25]
    iDate = iRec[25:33]
    iAge = iRec[33:35]
    iHandicap = iRec[35:37]
    iScore = iRec[37:40]
    iFinalScore = int(iScore) - int(iHandicap)

    cAge = int(iAge)

    if cAge <= 16:
        if iFinalScore < juniorTemp:
            cJuniorSecond = cJuniorFirst
            cJuniorFirst = iFinalScore
            juniorTemp = iFinalScore
            oJuniorSecond = oJuniorFirst
            oJuniorFirst = iName
        cJuniorTotal = cJuniorTotal + iFinalScore
        cJuniorCount = cJuniorCount + 1
    elif cAge >= 17 and cAge <= 49:
        if iFinalScore < amateurTemp:
            cAmateurSecond = cAmateurFirst
            cAmateurFirst = iFinalScore
            amateurTemp = iFinalScore
            oAmateurSecond = oAmateurFirst
            oAmateurFirst = iName
        cAmateurTotal = cAmateurTotal + iFinalScore
        cAmateurCount = cAmateurCount + 1
    elif cAge >= 50:
        if iFinalScore < seniorTemp:
            cSeniorSecond = cSeniorFirst
            cSeniorFirst = iFinalScore
            seniorTemp = iFinalScore
            oSeniorSecond = oSeniorFirst
            oSeniorFirst = iName
        cSeniorTotal = cSeniorTotal + iFinalScore
        cSeniorCount = cSeniorCount + 1

    return iFinalScore


def init():
    global oDate
    playerFile = open('/Users/hunter/Documents/Python/golf.dat', 'r')
    oDate = datetime.datetime.today().strftime('%m/%d/%Y')
    hdgs()
    iRec = read(playerFile)
    return iRec, playerFile


def read(playerFile):
    iRec = playerFile.readline()
    return iRec


def hdgs():
    global cPctr

    cPctr = cPctr + 1
    print("Date:", oDate, format(" ", "21s"), "Springfork Amateur Golf Club", format(" ", "22s"), "Page:",
          format(cPctr, "2d"))
    print(format(" ", "43s"), "Tournament Scores\n")

    print("Name", format(" ", "23s"), "Date", format(" ", "10s"), 'Age', format(
        " ", "8s"), "Handicap", format(" ", "8s"), "Score", format(" ", "5s"), "Final Score\n")


def closing(playerFile):
    cJuniorAverage = cJuniorTotal / cJuniorCount
    cAmateurAverage = cAmateurTotal / cAmateurCount
    cSeniorAverage = cSeniorTotal / cSeniorCount

    print("\n")
    print("Junior  Division Winners ", " 1st: ",
          oJuniorFirst, format(" ", "5s"), "2nd: ", oJuniorSecond)
    print("Junior  Division Average Score: ", format(cJuniorAverage, ".2f"))
    print("\n")
    print("Amateur Division Winners ", " 1st: ",
          oAmateurFirst, format(" ", "5s"), "2nd: ", oAmateurSecond)
    print("Amateur Division Average Score: ", format(cAmateurAverage, ".2f"))
    print("\n")
    print("Senior  Division Winners ", " 1st: ",
          oSeniorFirst, format(" ", "5s"), "2nd: ", oSeniorSecond)
    print("Senior  Division Average Score: ", format(cSeniorAverage, ".2f"))
    playerFile.close()


main()
