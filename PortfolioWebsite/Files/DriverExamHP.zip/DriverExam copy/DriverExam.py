# Hunter Peden
# 11-4-20
# Creating application the grades multiple choice questions for a drivers license exam
# Stores answers in a list. Program shows a message indication if they failed or passed.


correctAnswers = 0
incorrectAnswers = 0
studentAnswer = []
examAnswers = ["A", "C", "A", "A", "D", "B", "C", "A", "C",
               "B", "A", "D", "C", "A", "D", "C", "B", "B", "D", "A"]
incorrectQuestions = []


def main():
    studentExam = init()
    iAnswer = read(studentExam)
    studentAnswer = inputData(iAnswer)
    calcs()
    output()


def init():
    studentExam = open(
        '/Users/hunter/Documents/Python/ExamAnswers.dat', 'r')

    return studentExam


def inputData(iAnswer):
    studentAnswer.append(iAnswer[0:1])
    studentAnswer.append(iAnswer[1:2])
    studentAnswer.append(iAnswer[2:3])
    studentAnswer.append(iAnswer[3:4])
    studentAnswer.append(iAnswer[4:5])
    studentAnswer.append(iAnswer[5:6])
    studentAnswer.append(iAnswer[6:7])
    studentAnswer.append(iAnswer[7:8])
    studentAnswer.append(iAnswer[8:9])
    studentAnswer.append(iAnswer[9:10])
    studentAnswer.append(iAnswer[10:11])
    studentAnswer.append(iAnswer[11:12])
    studentAnswer.append(iAnswer[12:13])
    studentAnswer.append(iAnswer[13:14])
    studentAnswer.append(iAnswer[14:15])
    studentAnswer.append(iAnswer[15:16])
    studentAnswer.append(iAnswer[16:17])
    studentAnswer.append(iAnswer[17:18])
    studentAnswer.append(iAnswer[18:19])
    studentAnswer.append(iAnswer[19:20])
    return studentAnswer


def calcs():
    global studentAnswer
    global examAnswers
    global correctAnswers
    global incorrectAnswers

    i = 0

    for x in studentAnswer:
        if x == examAnswers[i]:
            correctAnswers = correctAnswers + 1
        else:
            incorrectQuestions.append(i + 1)
            incorrectAnswers = incorrectAnswers + 1
        i = i+1


def read(studentExam):
    iAnswer = studentExam.readline()
    return iAnswer


def output():
    global correctAnswers
    global incorrectAnswers
    if correctAnswers < 15:
        print("You have failed the Driver Exam.")
        print("Correct Answers: ", correctAnswers)
        print("Incorrect Answers: ", incorrectAnswers)
        print("You answered questions ", str(
            incorrectQuestions)[1:-1], " incorrectly!")
    else:
        print("You have passed the Driver Exam!")
        print("Correct Answers: ", correctAnswers)
        print("Incorrect Answers: ", incorrectAnswers)
        print("You answered questions ", str(
            incorrectQuestions)[1:-1], " incorrectly!")


main()
